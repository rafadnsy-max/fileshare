require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const MAX_MB = Math.max(1, Number(process.env.MAX_FILE_SIZE_MB || 500));
const MAX_FILES = Math.max(1, Math.min(100, Number(process.env.MAX_FILES_PER_UPLOAD || 20)));
const ROOT = __dirname;
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DATA_DIR = path.join(ROOT, "data");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, "fileshare.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size INTEGER NOT NULL,
    created_at TEXT NOT NULL
  )
`);

app.disable("x-powered-by");
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"]
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(ROOT, "public")));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, _file, cb) => cb(null, crypto.randomUUID())
});
const upload = multer({
  storage,
  limits: { fileSize: MAX_MB * 1024 * 1024, files: MAX_FILES },
  fileFilter: (_req, _file, cb) => cb(null, true)
});

function safeFile(row) {
  return {
    id: row.id,
    name: row.original_name,
    size: row.size,
    mimeType: row.mime_type,
    createdAt: row.created_at,
    downloadUrl: `/download/${encodeURIComponent(row.id)}`
  };
}

app.get("/api/files", (_req, res) => {
  const rows = db.prepare("SELECT * FROM files ORDER BY created_at DESC").all();
  res.json({ files: rows.map(safeFile) });
});

app.post("/api/upload", (req, res) => {
  upload.array("files", MAX_FILES)(req, res, (err) => {
    if (err) {
      const message = err.code === "LIMIT_FILE_SIZE"
        ? `File terlalu besar. Maksimum ${MAX_MB} MB per file.`
        : err.code === "LIMIT_FILE_COUNT"
          ? `Maksimum ${MAX_FILES} file sekali upload.`
          : err.message || "Upload gagal.";
      return res.status(400).json({ error: message });
    }
    const incoming = req.files || [];
    if (!incoming.length) return res.status(400).json({ error: "Pilih setidaknya satu file." });

    const insert = db.prepare(`
      INSERT INTO files (id, original_name, stored_name, mime_type, size, created_at)
      VALUES (@id, @original_name, @stored_name, @mime_type, @size, @created_at)
    `);
    const created = [];
    const transaction = db.transaction((items) => {
      for (const file of items) {
        const row = {
          id: crypto.randomUUID(),
          original_name: path.basename(file.originalname).slice(0, 255) || "file",
          stored_name: file.filename,
          mime_type: file.mimetype || "application/octet-stream",
          size: file.size,
          created_at: new Date().toISOString()
        };
        insert.run(row);
        created.push(safeFile(row));
      }
    });
    try {
      transaction(incoming);
      res.status(201).json({ files: created });
    } catch (e) {
      for (const file of incoming) fs.promises.unlink(file.path).catch(() => {});
      console.error(e);
      res.status(500).json({ error: "Tidak dapat menyimpan data file." });
    }
  });
});

app.get("/download/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM files WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).send("File tidak ditemukan.");
  const diskPath = path.join(UPLOAD_DIR, row.stored_name);
  if (!fs.existsSync(diskPath)) return res.status(404).send("File tidak tersedia di penyimpanan.");
  res.download(diskPath, row.original_name);
});

app.delete("/api/files/:id", (req, res) => {
  const expected = process.env.ADMIN_TOKEN;
  const supplied = req.get("x-admin-token");
  if (!expected || expected === "change-this-to-a-long-random-secret" ||
      !supplied || supplied.length !== expected.length ||
      !crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected))) {
    return res.status(401).json({ error: "Token admin tidak valid." });
  }
  const row = db.prepare("SELECT * FROM files WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "File tidak ditemukan." });
  db.prepare("DELETE FROM files WHERE id = ?").run(row.id);
  fs.promises.unlink(path.join(UPLOAD_DIR, row.stored_name)).catch(() => {});
  res.json({ ok: true });
});

app.get("/api/config", (_req, res) => {
  res.json({ maxFileSizeMB: MAX_MB, maxFilesPerUpload: MAX_FILES });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan pada server." });
});

app.listen(PORT, () => {
  console.log(`FileShare berjalan di http://localhost:${PORT}`);
});
