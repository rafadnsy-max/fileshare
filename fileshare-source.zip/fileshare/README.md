# FileShare

Aplikasi file sharing bergaya dark mode menggunakan Node.js, Express, Multer, dan SQLite.

## Fitur
- Upload beberapa file sekaligus melalui file picker atau drag & drop.
- Progress bar upload.
- Daftar file terbaru.
- Link download langsung dan tombol salin link.
- Admin token untuk menghapus file.
- Metadata disimpan di SQLite; file disimpan di folder `uploads/`.
- Batas ukuran dan jumlah file dapat diatur lewat environment.

## Persyaratan
- Node.js 20 atau lebih baru
- npm

## Menjalankan di komputer sendiri

1. Ekstrak ZIP ini.
2. Buka terminal di folder project.
3. Install dependensi:

   ```bash
   npm install
   ```

4. Salin `.env.example` menjadi `.env`.
5. Ubah `ADMIN_TOKEN` di `.env` menjadi secret acak yang panjang. Jangan gunakan token contoh.
6. Jalankan:

   ```bash
   npm start
   ```

7. Buka `http://localhost:3000`.

## Konfigurasi

| Variabel | Default | Keterangan |
|---|---:|---|
| `PORT` | `3000` | Port HTTP |
| `BASE_URL` | `http://localhost:3000` | URL publik (disediakan untuk konfigurasi deployment) |
| `ADMIN_TOKEN` | — | Token untuk menghapus file |
| `MAX_FILE_SIZE_MB` | `500` | Maksimum ukuran setiap file |
| `MAX_FILES_PER_UPLOAD` | `20` | Maksimum file per satu permintaan upload |

## Deploy ke server / VPS

1. Siapkan VPS dengan Node.js 20+.
2. Upload folder project dan jalankan `npm install`.
3. Buat `.env` dengan token admin yang kuat dan batas upload yang sesuai.
4. Jalankan `npm start` menggunakan process manager seperti PM2 atau systemd.
5. Pasang Nginx/Caddy sebagai reverse proxy dan aktifkan HTTPS.
6. Atur batas body upload pada reverse proxy agar sesuai dengan `MAX_FILE_SIZE_MB`.
7. Pastikan folder `uploads/` dan `data/` berada pada disk persisten dan rutin dicadangkan.

Contoh Nginx:

```nginx
server {
    listen 80;
    server_name files.example.com;
    client_max_body_size 500m;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

## API ringkas

- `GET /api/config` — batas upload.
- `GET /api/files` — daftar file.
- `POST /api/upload` — multipart form dengan field `files` (dapat berulang).
- `GET /download/:id` — download file.
- `DELETE /api/files/:id` — hapus file, memerlukan header `x-admin-token`.

## Catatan produksi

Ini adalah starter project yang dapat dijalankan sendiri, bukan layanan cloud siap pakai. Sebelum dibuka untuk publik, tambahkan kebijakan retensi/kuota, pemindaian malware, CAPTCHA atau autentikasi untuk mencegah penyalahgunaan, monitoring, backup, dan pembatasan bandwidth. File yang diunggah dapat diakses oleh siapa pun yang memiliki link; jangan unggah data rahasia. Gunakan HTTPS saat deployment. Database dan file upload harus disimpan pada disk persisten.
