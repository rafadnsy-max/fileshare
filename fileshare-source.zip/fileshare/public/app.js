const $ = (id) => document.getElementById(id);
const dropZone = $("dropZone");
const input = $("fileInput");
const statusBox = $("status");
const progressWrap = $("progressWrap");
const progressBar = $("progressBar");
const progressText = $("progressText");
const progressPercent = $("progressPercent");
const fileList = $("fileList");
const adminDialog = $("adminDialog");
let adminToken = "";

function formatBytes(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, index)).toFixed(index ? 1 : 0)} ${units[index]}`;
}
function formatDate(value) {
  return new Date(value).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });
}
function iconFor(name) {
  const ext = (name.split(".").pop() || "").toLowerCase();
  if (["jpg","jpeg","png","gif","webp","svg"].includes(ext)) return "▧";
  if (["mp4","mov","mkv","webm"].includes(ext)) return "▶";
  if (["mp3","wav","ogg"].includes(ext)) return "♫";
  if (["zip","rar","7z","tar","gz"].includes(ext)) return "▣";
  if (["pdf"].includes(ext)) return "PDF";
  if (["doc","docx","txt","rtf"].includes(ext)) return "文";
  return "↗";
}
function showStatus(message, error = false) {
  statusBox.textContent = message;
  statusBox.classList.toggle("error", error);
}
async function loadFiles() {
  fileList.innerHTML = '<div class="empty-state">Memuat daftar file...</div>';
  try {
    const response = await fetch("/api/files");
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Gagal memuat file.");
    renderFiles(data.files || []);
  } catch (error) {
    fileList.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
  }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[char]));
}
function renderFiles(files) {
  $("fileCount").textContent = `${files.length} file tersimpan`;
  if (!files.length) {
    fileList.innerHTML = '<div class="empty-state">Belum ada file. Upload file pertama kamu di atas.</div>';
    return;
  }
  fileList.innerHTML = files.map(file => `
    <article class="file-row">
      <div class="file-icon">${iconFor(file.name)}</div>
      <div class="file-info">
        <div class="file-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</div>
        <div class="file-meta">${formatBytes(file.size)} · ${formatDate(file.createdAt)}</div>
      </div>
      <div class="file-actions">
        <button class="action copy-action" data-url="${escapeHtml(new URL(file.downloadUrl, location.origin).href)}">Salin link</button>
        <a class="action" href="${escapeHtml(file.downloadUrl)}">Download</a>
        ${adminToken ? `<button class="action delete-action" data-delete="${escapeHtml(file.id)}">Hapus</button>` : ""}
      </div>
    </article>`).join("");
  fileList.querySelectorAll(".copy-action").forEach(button => {
    button.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(button.dataset.url);
        button.textContent = "Tersalin!";
        setTimeout(() => button.textContent = "Salin link", 1300);
      } catch { window.prompt("Salin link ini:", button.dataset.url); }
    });
  });
  fileList.querySelectorAll("[data-delete]").forEach(button => {
    button.addEventListener("click", async () => {
      if (!confirm("Hapus file ini secara permanen?")) return;
      try {
        const response = await fetch(`/api/files/${encodeURIComponent(button.dataset.delete)}`, {
          method: "DELETE", headers: { "x-admin-token": adminToken }
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "Gagal menghapus file.");
        loadFiles();
      } catch (error) { alert(error.message); }
    });
  });
}
function uploadFiles(files) {
  if (!files || !files.length) return;
  const form = new FormData();
  [...files].forEach(file => form.append("files", file));
  progressWrap.hidden = false;
  progressBar.style.width = "0%";
  progressText.textContent = `Mengupload ${files.length} file...`;
  progressPercent.textContent = "0%";
  showStatus("");
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "/api/upload");
  xhr.upload.onprogress = event => {
    if (event.lengthComputable) {
      const percent = Math.round(event.loaded / event.total * 100);
      progressBar.style.width = `${percent}%`;
      progressPercent.textContent = `${percent}%`;
    }
  };
  xhr.onload = () => {
    let result = {};
    try { result = JSON.parse(xhr.responseText); } catch {}
    if (xhr.status >= 200 && xhr.status < 300) {
      progressBar.style.width = "100%";
      progressText.textContent = "Upload selesai";
      progressPercent.textContent = "100%";
      showStatus(`${(result.files || []).length} file berhasil diupload.`);
      loadFiles();
    } else {
      showStatus(result.error || "Upload gagal.", true);
      progressText.textContent = "Upload gagal";
    }
    input.value = "";
  };
  xhr.onerror = () => { showStatus("Koneksi gagal saat upload.", true); progressText.textContent = "Upload gagal"; };
  xhr.send(form);
}
input.addEventListener("change", () => uploadFiles(input.files));
["dragenter","dragover"].forEach(type => dropZone.addEventListener(type, event => {
  event.preventDefault(); dropZone.classList.add("dragging");
}));
["dragleave","drop"].forEach(type => dropZone.addEventListener(type, event => {
  event.preventDefault(); dropZone.classList.remove("dragging");
}));
dropZone.addEventListener("drop", event => uploadFiles(event.dataTransfer.files));
$("refreshButton").addEventListener("click", loadFiles);
$("adminOpen").addEventListener("click", () => adminDialog.showModal());
$("saveAdmin").addEventListener("click", () => {
  const token = $("adminToken").value.trim();
  if (!token) { $("adminStatus").textContent = "Token wajib diisi."; return; }
  adminToken = token;
  $("adminStatus").textContent = "Mode admin aktif di halaman ini.";
  adminToken && loadFiles();
  setTimeout(() => adminDialog.close(), 650);
});
fetch("/api/config").then(r => r.json()).then(config => {
  $("maxSize").textContent = config.maxFileSizeMB;
}).catch(() => {});
loadFiles();
